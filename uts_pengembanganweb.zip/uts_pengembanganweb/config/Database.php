<?php
/**
 * Database Configuration Class
 * Menggunakan PDO untuk koneksi database MySQL
 */
class Database {
    private $host = "localhost";
    private $db_name = "ecommerce_mvc";
    private $username = "root";
    private $password = "";
    private $conn;

    /**
     * Membuat dan mengembalikan objek PDO connection
     * @return PDO
     */
    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            echo "Koneksi database gagal: " . $e->getMessage();
        }
        return $this->conn;
    }
}

