<?php
/**
 * Base Controller Class
 * Menyediakan fungsi render view untuk semua controller
 */
class Controller {
    /**
     * Merender view dengan layout
     * @param string $view Path view yang akan dirender
     * @param array $data Data yang akan dikirim ke view
     */
    protected function render($view, $data = []) {
        extract($data);
        require_once __DIR__ . '/../views/layout/header.php';
        require_once __DIR__ . '/../views/' . $view . '.php';
        require_once __DIR__ . '/../views/layout/footer.php';
    }

    /**
     * Redirect ke URL tertentu
     * @param string $url
     */
    protected function redirect($url) {
        header("Location: " . $url);
        exit();
    }
}

