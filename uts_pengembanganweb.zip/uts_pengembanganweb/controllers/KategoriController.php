<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/KategoriModel.php';

/**
 * Controller untuk fitur Kategori
 */
class KategoriController extends Controller {
    private $model;

    public function __construct() {
        $this->model = new KategoriModel();
    }

    /**
     * Menampilkan daftar kategori
     */
    public function index() {
        $kategori = $this->model->getAll();
        $this->render('kategori/index', ['kategori' => $kategori]);
    }

    /**
     * Menampilkan form tambah kategori
     */
    public function create() {
        $this->render('kategori/create');
    }

    /**
     * Menyimpan kategori baru
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_kategori = $_POST['nama_kategori'] ?? '';
            $deskripsi = $_POST['deskripsi'] ?? '';
            
            if (!empty($nama_kategori)) {
                $this->model->create($nama_kategori, $deskripsi);
            }
        }
        $this->redirect('index.php?page=kategori');
    }

    /**
     * Menampilkan form edit kategori
     */
    public function edit($id) {
        $kategori = $this->model->getById($id);
        if (!$kategori) {
            $this->redirect('index.php?page=kategori');
        }
        $this->render('kategori/edit', ['kategori' => $kategori]);
    }

    /**
     * Mengupdate kategori
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_kategori = $_POST['nama_kategori'] ?? '';
            $deskripsi = $_POST['deskripsi'] ?? '';
            
            if (!empty($nama_kategori)) {
                $this->model->update($id, $nama_kategori, $deskripsi);
            }
        }
        $this->redirect('index.php?page=kategori');
    }

    /**
     * Menghapus kategori
     */
    public function delete($id) {
        $this->model->delete($id);
        $this->redirect('index.php?page=kategori');
    }
}

