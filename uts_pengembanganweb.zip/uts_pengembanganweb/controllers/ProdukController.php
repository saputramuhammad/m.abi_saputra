<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/ProdukModel.php';
require_once __DIR__ . '/../models/KategoriModel.php';
require_once __DIR__ . '/../models/SupplierModel.php';

/**
 * Controller untuk fitur Produk
 */
class ProdukController extends Controller {
    private $model;
    private $kategoriModel;
    private $supplierModel;

    public function __construct() {
        $this->model = new ProdukModel();
        $this->kategoriModel = new KategoriModel();
        $this->supplierModel = new SupplierModel();
    }

    /**
     * Menampilkan daftar produk
     */
    public function index() {
        $produk = $this->model->getAllWithRelations();
        $this->render('produk/index', ['produk' => $produk]);
    }

    /**
     * Menampilkan form tambah produk
     */
    public function create() {
        $kategori = $this->kategoriModel->getAll();
        $supplier = $this->supplierModel->getAll();
        $this->render('produk/create', [
            'kategori' => $kategori,
            'supplier' => $supplier
        ]);
    }

    /**
     * Menyimpan produk baru
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_produk = $_POST['nama_produk'] ?? '';
            $id_kategori = $_POST['id_kategori'] ?? 0;
            $id_supplier = $_POST['id_supplier'] ?? 0;
            $harga = $_POST['harga'] ?? 0;
            $stok = $_POST['stok'] ?? 0;
            $deskripsi = $_POST['deskripsi'] ?? '';
            
            if (!empty($nama_produk) && $id_kategori > 0 && $id_supplier > 0) {
                $this->model->create($nama_produk, $id_kategori, $id_supplier, $harga, $stok, $deskripsi);
            }
        }
        $this->redirect('index.php?page=produk');
    }

    /**
     * Menampilkan form edit produk
     */
    public function edit($id) {
        $produk = $this->model->getByIdWithRelations($id);
        if (!$produk) {
            $this->redirect('index.php?page=produk');
        }
        $kategori = $this->kategoriModel->getAll();
        $supplier = $this->supplierModel->getAll();
        $this->render('produk/edit', [
            'produk' => $produk,
            'kategori' => $kategori,
            'supplier' => $supplier
        ]);
    }

    /**
     * Mengupdate produk
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_produk = $_POST['nama_produk'] ?? '';
            $id_kategori = $_POST['id_kategori'] ?? 0;
            $id_supplier = $_POST['id_supplier'] ?? 0;
            $harga = $_POST['harga'] ?? 0;
            $stok = $_POST['stok'] ?? 0;
            $deskripsi = $_POST['deskripsi'] ?? '';
            
            if (!empty($nama_produk) && $id_kategori > 0 && $id_supplier > 0) {
                $this->model->update($id, $nama_produk, $id_kategori, $id_supplier, $harga, $stok, $deskripsi);
            }
        }
        $this->redirect('index.php?page=produk');
    }

    /**
     * Menghapus produk
     */
    public function delete($id) {
        $this->model->delete($id);
        $this->redirect('index.php?page=produk');
    }
}

