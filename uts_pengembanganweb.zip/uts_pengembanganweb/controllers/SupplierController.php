<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/SupplierModel.php';

/**
 * Controller untuk fitur Supplier
 */
class SupplierController extends Controller {
    private $model;

    public function __construct() {
        $this->model = new SupplierModel();
    }

    /**
     * Menampilkan daftar supplier
     */
    public function index() {
        $supplier = $this->model->getAll();
        $this->render('supplier/index', ['supplier' => $supplier]);
    }

    /**
     * Menampilkan form tambah supplier
     */
    public function create() {
        $this->render('supplier/create');
    }

    /**
     * Menyimpan supplier baru
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_supplier = $_POST['nama_supplier'] ?? '';
            $alamat = $_POST['alamat'] ?? '';
            $telepon = $_POST['telepon'] ?? '';
            $email = $_POST['email'] ?? '';
            
            if (!empty($nama_supplier)) {
                $this->model->create($nama_supplier, $alamat, $telepon, $email);
            }
        }
        $this->redirect('index.php?page=supplier');
    }

    /**
     * Menampilkan form edit supplier
     */
    public function edit($id) {
        $supplier = $this->model->getById($id);
        if (!$supplier) {
            $this->redirect('index.php?page=supplier');
        }
        $this->render('supplier/edit', ['supplier' => $supplier]);
    }

    /**
     * Mengupdate supplier
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_supplier = $_POST['nama_supplier'] ?? '';
            $alamat = $_POST['alamat'] ?? '';
            $telepon = $_POST['telepon'] ?? '';
            $email = $_POST['email'] ?? '';
            
            if (!empty($nama_supplier)) {
                $this->model->update($id, $nama_supplier, $alamat, $telepon, $email);
            }
        }
        $this->redirect('index.php?page=supplier');
    }

    /**
     * Menghapus supplier
     */
    public function delete($id) {
        $this->model->delete($id);
        $this->redirect('index.php?page=supplier');
    }
}

