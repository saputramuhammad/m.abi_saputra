<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/TransaksiModel.php';
require_once __DIR__ . '/../models/ProdukModel.php';

/**
 * Controller untuk fitur Transaksi
 */
class TransaksiController extends Controller {
    private $model;
    private $produkModel;

    public function __construct() {
        $this->model = new TransaksiModel();
        $this->produkModel = new ProdukModel();
    }

    /**
     * Menampilkan daftar transaksi
     */
    public function index() {
        $transaksi = $this->model->getAllWithDetails();
        $this->render('transaksi/index', ['transaksi' => $transaksi]);
    }

    /**
     * Menampilkan form tambah transaksi
     */
    public function create() {
        $produk = $this->produkModel->getAllWithRelations();
        $this->render('transaksi/create', ['produk' => $produk]);
    }

    /**
     * Menyimpan transaksi baru
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama_pembeli = $_POST['nama_pembeli'] ?? '';
            $produk_ids = $_POST['id_produk'] ?? [];
            $jumlahs = $_POST['jumlah'] ?? [];
            $harga_satuans = $_POST['harga_satuan'] ?? [];
            
            $produk_list = [];
            for ($i = 0; $i < count($produk_ids); $i++) {
                if (isset($produk_ids[$i]) && $jumlahs[$i] > 0) {
                    $produk_list[] = [
                        'id_produk' => $produk_ids[$i],
                        'jumlah' => $jumlahs[$i],
                        'harga_satuan' => $harga_satuans[$i]
                    ];
                }
            }
            
            if (!empty($nama_pembeli) && !empty($produk_list)) {
                $this->model->create($nama_pembeli, $produk_list);
            }
        }
        $this->redirect('index.php?page=transaksi');
    }

    /**
     * Menampilkan detail transaksi
     */
    public function show($id) {
        $transaksi = $this->model->getByIdWithDetails($id);
        if (!$transaksi) {
            $this->redirect('index.php?page=transaksi');
        }
        $this->render('transaksi/show', ['transaksi' => $transaksi]);
    }

    /**
     * Menghapus transaksi
     */
    public function delete($id) {
        $this->model->delete($id);
        $this->redirect('index.php?page=transaksi');
    }
}

