-- Database: ecommerce_mvc
-- Membuat database
CREATE DATABASE IF NOT EXISTS ecommerce_mvc CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE ecommerce_mvc;

-- Tabel Kategori
CREATE TABLE IF NOT EXISTS kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabel Supplier
CREATE TABLE IF NOT EXISTS supplier (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_supplier VARCHAR(100) NOT NULL,
    alamat TEXT,
    telepon VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabel Produk
CREATE TABLE IF NOT EXISTS produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(150) NOT NULL,
    id_kategori INT NOT NULL,
    id_supplier INT NOT NULL,
    harga DECIMAL(12,2) NOT NULL DEFAULT 0,
    stok INT NOT NULL DEFAULT 0,
    deskripsi TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_kategori) REFERENCES kategori(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_supplier) REFERENCES supplier(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Tabel Transaksi
CREATE TABLE IF NOT EXISTS transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_harga DECIMAL(15,2) NOT NULL DEFAULT 0,
    nama_pembeli VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabel Detail Transaksi
CREATE TABLE IF NOT EXISTS detail_transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_transaksi INT NOT NULL,
    id_produk INT NOT NULL,
    jumlah INT NOT NULL DEFAULT 1,
    harga_satuan DECIMAL(12,2) NOT NULL DEFAULT 0,
    subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (id_transaksi) REFERENCES transaksi(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_produk) REFERENCES produk(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Data Sample Kategori
INSERT INTO kategori (nama_kategori, deskripsi) VALUES
('Elektronik', 'Produk elektronik dan gadget'),
('Pakaian', 'Berbagai jenis pakaian fashion'),
('Makanan & Minuman', 'Produk makanan dan minuman'),
('Perabotan', 'Furniture dan perabotan rumah tangga');

-- Data Sample Supplier
INSERT INTO supplier (nama_supplier, alamat, telepon, email) VALUES
('PT Maju Jaya', 'Jl. Sudirman No. 123, Jakarta', '021-1234567', 'maju@jaya.com'),
('CV Sukses Abadi', 'Jl. Thamrin No. 45, Bandung', '022-7654321', 'sukses@abadi.com'),
('UD Sejahtera', 'Jl. Ahmad Yani No. 78, Surabaya', '031-9876543', 'sejahtera@ud.com');

-- Data Sample Produk
INSERT INTO produk (nama_produk, id_kategori, id_supplier, harga, stok, deskripsi) VALUES
('Smartphone Samsung A54', 1, 1, 4999000.00, 50, 'Smartphone dengan kamera 50MP dan baterai 5000mAh'),
('Laptop ASUS VivoBook', 1, 1, 7500000.00, 30, 'Laptop ringan dengan prosesor Intel Core i5'),
('Kaos Polos Cotton', 2, 2, 85000.00, 200, 'Kaos polos bahan katun nyaman dipakai'),
('Kemeja Flanel', 2, 2, 175000.00, 100, 'Kemeja flanel premium dengan motif klasik'),
('Kopi Arabika 250g', 3, 3, 75000.00, 150, 'Kopi arabika asli dari pegunungan Gayo'),
('Teh Hijau Organik', 3, 3, 45000.00, 120, 'Teh hijau organik tanpa bahan pengawet'),
('Meja Kerja Minimalis', 4, 1, 1200000.00, 20, 'Meja kerja dengan desain minimalis modern'),
('Kursi Gaming', 4, 2, 1850000.00, 15, 'Kursi gaming ergonomis dengan sandaran tinggi');

