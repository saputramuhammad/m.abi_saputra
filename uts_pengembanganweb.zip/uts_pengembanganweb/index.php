<?php
/**
 * Front Controller
 * Entry point aplikasi MVC E-Commerce
 */

// Autoload controller
function autoloadController($className) {
    $file = __DIR__ . '/controllers/' . $className . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
}
spl_autoload_register('autoloadController');

// Mendapatkan parameter dari URL
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Routing
switch ($page) {
    case 'kategori':
        $controller = new KategoriController();
        break;
    case 'supplier':
        $controller = new SupplierController();
        break;
    case 'produk':
        $controller = new ProdukController();
        break;
    case 'transaksi':
        $controller = new TransaksiController();
        break;
    case 'dashboard':
    default:
        // Tampilkan dashboard
        require_once __DIR__ . '/views/layout/header.php';
        require_once __DIR__ . '/views/dashboard.php';
        require_once __DIR__ . '/views/layout/footer.php';
        exit();
}

// Panggil method controller berdasarkan action
if (method_exists($controller, $action)) {
    if ($id > 0) {
        $controller->$action($id);
    } else {
        $controller->$action();
    }
} else {
    // Fallback ke index jika action tidak ditemukan
    $controller->index();
}

