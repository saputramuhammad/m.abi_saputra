<?php
require_once __DIR__ . '/Model.php';

/**
 * Model untuk tabel Kategori
 */
class KategoriModel extends Model {
    protected $table = "kategori";

    /**
     * Membuat kategori baru
     * @param string $nama_kategori
     * @param string $deskripsi
     * @return bool
     */
    public function create($nama_kategori, $deskripsi) {
        $query = "INSERT INTO " . $this->table . " (nama_kategori, deskripsi) VALUES (:nama_kategori, :deskripsi)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":nama_kategori", $nama_kategori);
        $stmt->bindParam(":deskripsi", $deskripsi);
        return $stmt->execute();
    }

    /**
     * Mengupdate data kategori
     * @param int $id
     * @param string $nama_kategori
     * @param string $deskripsi
     * @return bool
     */
    public function update($id, $nama_kategori, $deskripsi) {
        $query = "UPDATE " . $this->table . " SET nama_kategori = :nama_kategori, deskripsi = :deskripsi WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->bindParam(":nama_kategori", $nama_kategori);
        $stmt->bindParam(":deskripsi", $deskripsi);
        return $stmt->execute();
    }
}

