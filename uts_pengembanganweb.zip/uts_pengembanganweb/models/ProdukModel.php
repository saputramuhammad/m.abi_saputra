<?php
require_once __DIR__ . '/Model.php';

/**
 * Model untuk tabel Produk
 */
class ProdukModel extends Model {
    protected $table = "produk";

    /**
     * Mengambil semua produk dengan join ke kategori dan supplier
     * @return array
     */
    public function getAllWithRelations() {
        $query = "SELECT p.*, k.nama_kategori, s.nama_supplier 
                  FROM " . $this->table . " p
                  LEFT JOIN kategori k ON p.id_kategori = k.id
                  LEFT JOIN supplier s ON p.id_supplier = s.id
                  ORDER BY p.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Mengambil produk berdasarkan ID dengan relasi
     * @param int $id
     * @return array|false
     */
    public function getByIdWithRelations($id) {
        $query = "SELECT p.*, k.nama_kategori, s.nama_supplier 
                  FROM " . $this->table . " p
                  LEFT JOIN kategori k ON p.id_kategori = k.id
                  LEFT JOIN supplier s ON p.id_supplier = s.id
                  WHERE p.id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * Membuat produk baru
     * @param string $nama_produk
     * @param int $id_kategori
     * @param int $id_supplier
     * @param float $harga
     * @param int $stok
     * @param string $deskripsi
     * @return bool
     */
    public function create($nama_produk, $id_kategori, $id_supplier, $harga, $stok, $deskripsi) {
        $query = "INSERT INTO " . $this->table . " (nama_produk, id_kategori, id_supplier, harga, stok, deskripsi) 
                  VALUES (:nama_produk, :id_kategori, :id_supplier, :harga, :stok, :deskripsi)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":nama_produk", $nama_produk);
        $stmt->bindParam(":id_kategori", $id_kategori, PDO::PARAM_INT);
        $stmt->bindParam(":id_supplier", $id_supplier, PDO::PARAM_INT);
        $stmt->bindParam(":harga", $harga);
        $stmt->bindParam(":stok", $stok, PDO::PARAM_INT);
        $stmt->bindParam(":deskripsi", $deskripsi);
        return $stmt->execute();
    }

    /**
     * Mengupdate data produk
     * @param int $id
     * @param string $nama_produk
     * @param int $id_kategori
     * @param int $id_supplier
     * @param float $harga
     * @param int $stok
     * @param string $deskripsi
     * @return bool
     */
    public function update($id, $nama_produk, $id_kategori, $id_supplier, $harga, $stok, $deskripsi) {
        $query = "UPDATE " . $this->table . " 
                  SET nama_produk = :nama_produk, id_kategori = :id_kategori, id_supplier = :id_supplier, 
                      harga = :harga, stok = :stok, deskripsi = :deskripsi 
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->bindParam(":nama_produk", $nama_produk);
        $stmt->bindParam(":id_kategori", $id_kategori, PDO::PARAM_INT);
        $stmt->bindParam(":id_supplier", $id_supplier, PDO::PARAM_INT);
        $stmt->bindParam(":harga", $harga);
        $stmt->bindParam(":stok", $stok, PDO::PARAM_INT);
        $stmt->bindParam(":deskripsi", $deskripsi);
        return $stmt->execute();
    }
}

