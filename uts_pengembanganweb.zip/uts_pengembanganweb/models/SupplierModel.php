<?php
require_once __DIR__ . '/Model.php';

/**
 * Model untuk tabel Supplier
 */
class SupplierModel extends Model {
    protected $table = "supplier";

    /**
     * Membuat supplier baru
     * @param string $nama_supplier
     * @param string $alamat
     * @param string $telepon
     * @param string $email
     * @return bool
     */
    public function create($nama_supplier, $alamat, $telepon, $email) {
        $query = "INSERT INTO " . $this->table . " (nama_supplier, alamat, telepon, email) VALUES (:nama_supplier, :alamat, :telepon, :email)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":nama_supplier", $nama_supplier);
        $stmt->bindParam(":alamat", $alamat);
        $stmt->bindParam(":telepon", $telepon);
        $stmt->bindParam(":email", $email);
        return $stmt->execute();
    }

    /**
     * Mengupdate data supplier
     * @param int $id
     * @param string $nama_supplier
     * @param string $alamat
     * @param string $telepon
     * @param string $email
     * @return bool
     */
    public function update($id, $nama_supplier, $alamat, $telepon, $email) {
        $query = "UPDATE " . $this->table . " SET nama_supplier = :nama_supplier, alamat = :alamat, telepon = :telepon, email = :email WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->bindParam(":nama_supplier", $nama_supplier);
        $stmt->bindParam(":alamat", $alamat);
        $stmt->bindParam(":telepon", $telepon);
        $stmt->bindParam(":email", $email);
        return $stmt->execute();
    }
}

