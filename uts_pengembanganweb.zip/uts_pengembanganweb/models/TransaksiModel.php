<?php
require_once __DIR__ . '/Model.php';

/**
 * Model untuk tabel Transaksi dan Detail Transaksi
 */
class TransaksiModel extends Model {
    protected $table = "transaksi";

    /**
     * Mengambil semua transaksi dengan detail produk
     * @return array
     */
    public function getAllWithDetails() {
        $query = "SELECT t.*, 
                  GROUP_CONCAT(p.nama_produk SEPARATOR ', ') as produk_list,
                  SUM(dt.jumlah) as total_jumlah
                  FROM " . $this->table . " t
                  LEFT JOIN detail_transaksi dt ON t.id = dt.id_transaksi
                  LEFT JOIN produk p ON dt.id_produk = p.id
                  GROUP BY t.id
                  ORDER BY t.tanggal DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Mengambil transaksi berdasarkan ID dengan detail lengkap
     * @param int $id
     * @return array|false
     */
    public function getByIdWithDetails($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();
        $transaksi = $stmt->fetch();
        
        if ($transaksi) {
            $query = "SELECT dt.*, p.nama_produk 
                      FROM detail_transaksi dt
                      LEFT JOIN produk p ON dt.id_produk = p.id
                      WHERE dt.id_transaksi = :id_transaksi";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id_transaksi", $id, PDO::PARAM_INT);
            $stmt->execute();
            $transaksi['detail'] = $stmt->fetchAll();
        }
        
        return $transaksi;
    }

    /**
     * Membuat transaksi baru beserta detailnya
     * @param string $nama_pembeli
     * @param array $produk_list Array berisi [id_produk, jumlah, harga_satuan]
     * @return bool
     */
    public function create($nama_pembeli, $produk_list) {
        try {
            $this->conn->beginTransaction();
            
            $total_harga = 0;
            foreach ($produk_list as $item) {
                $total_harga += $item['jumlah'] * $item['harga_satuan'];
            }
            
            $query = "INSERT INTO " . $this->table . " (nama_pembeli, total_harga) VALUES (:nama_pembeli, :total_harga)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":nama_pembeli", $nama_pembeli);
            $stmt->bindParam(":total_harga", $total_harga);
            $stmt->execute();
            
            $id_transaksi = $this->conn->lastInsertId();
            
            $query = "INSERT INTO detail_transaksi (id_transaksi, id_produk, jumlah, harga_satuan, subtotal) 
                      VALUES (:id_transaksi, :id_produk, :jumlah, :harga_satuan, :subtotal)";
            $stmt = $this->conn->prepare($query);
            
            foreach ($produk_list as $item) {
                $subtotal = $item['jumlah'] * $item['harga_satuan'];
                $stmt->bindParam(":id_transaksi", $id_transaksi, PDO::PARAM_INT);
                $stmt->bindParam(":id_produk", $item['id_produk'], PDO::PARAM_INT);
                $stmt->bindParam(":jumlah", $item['jumlah'], PDO::PARAM_INT);
                $stmt->bindParam(":harga_satuan", $item['harga_satuan']);
                $stmt->bindParam(":subtotal", $subtotal);
                $stmt->execute();
                
                // Update stok produk
                $query_stok = "UPDATE produk SET stok = stok - :jumlah WHERE id = :id_produk";
                $stmt_stok = $this->conn->prepare($query_stok);
                $stmt_stok->bindParam(":jumlah", $item['jumlah'], PDO::PARAM_INT);
                $stmt_stok->bindParam(":id_produk", $item['id_produk'], PDO::PARAM_INT);
                $stmt_stok->execute();
            }
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    /**
     * Menghapus transaksi beserta detailnya
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        try {
            $this->conn->beginTransaction();
            
            // Kembalikan stok produk
            $query = "SELECT * FROM detail_transaksi WHERE id_transaksi = :id_transaksi";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id_transaksi", $id, PDO::PARAM_INT);
            $stmt->execute();
            $details = $stmt->fetchAll();
            
            foreach ($details as $detail) {
                $query_stok = "UPDATE produk SET stok = stok + :jumlah WHERE id = :id_produk";
                $stmt_stok = $this->conn->prepare($query_stok);
                $stmt_stok->bindParam(":jumlah", $detail['jumlah'], PDO::PARAM_INT);
                $stmt_stok->bindParam(":id_produk", $detail['id_produk'], PDO::PARAM_INT);
                $stmt_stok->execute();
            }
            
            // Hapus detail transaksi
            $query = "DELETE FROM detail_transaksi WHERE id_transaksi = :id_transaksi";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id_transaksi", $id, PDO::PARAM_INT);
            $stmt->execute();
            
            // Hapus transaksi
            $query = "DELETE FROM " . $this->table . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->execute();
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }
}

