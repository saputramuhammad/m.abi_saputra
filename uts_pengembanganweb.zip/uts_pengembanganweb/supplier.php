<?php
/**
 * Redirect ke front controller MVC
 * File ini disediakan untuk kompatibilitas atau dapat dihapus
 */
header("Location: index.php?page=supplier");
exit();

