<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-speedometer2"></i> Dashboard</h2>
</div>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Kategori</h6>
                        <h3><i class="bi bi-tags"></i></h3>
                    </div>
                    <a href="index.php?page=kategori" class="btn btn-light btn-sm">Kelola</a>
                </div>
                <p class="card-text mt-2">Kelola data kategori produk</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Supplier</h6>
                        <h3><i class="bi bi-truck"></i></h3>
                    </div>
                    <a href="index.php?page=supplier" class="btn btn-light btn-sm">Kelola</a>
                </div>
                <p class="card-text mt-2">Kelola data supplier produk</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card bg-warning text-dark">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Produk</h6>
                        <h3><i class="bi bi-box-seam"></i></h3>
                    </div>
                    <a href="index.php?page=produk" class="btn btn-light btn-sm">Kelola</a>
                </div>
                <p class="card-text mt-2">Kelola data produk</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Transaksi</h6>
                        <h3><i class="bi bi-cart-check"></i></h3>
                    </div>
                    <a href="index.php?page=transaksi" class="btn btn-light btn-sm">Kelola</a>
                </div>
                <p class="card-text mt-2">Kelola data transaksi penjualan</p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0"><i class="bi bi-info-circle"></i> Selamat Datang di Aplikasi E-Commerce MVC</h5>
    </div>
    <div class="card-body">
        <p>Aplikasi ini dibangun menggunakan paradigma <strong>Model-View-Controller (MVC)</strong> dengan bahasa pemrograman PHP.</p>
        <h6>Fitur Utama:</h6>
        <ul>
            <li><strong>Kategori</strong> - Manajemen kategori produk (Tambah, Edit, Hapus)</li>
            <li><strong>Supplier</strong> - Manajemen data supplier (Tambah, Edit, Hapus)</li>
            <li><strong>Produk</strong> - Manajemen produk dengan relasi ke kategori dan supplier (Tambah, Edit, Hapus)</li>
            <li><strong>Transaksi</strong> - Manajemen transaksi penjualan dengan multi-produk per transaksi</li>
        </ul>
        <h6>Struktur MVC:</h6>
        <ul>
            <li><strong>Model</strong> - Berisi logika database dan query SQL (folder <code>models/</code>)</li>
            <li><strong>View</strong> - Berisi tampilan HTML/UI (folder <code>views/</code>)</li>
            <li><strong>Controller</strong> - Berisi logika bisnis dan penghubung Model-View (folder <code>controllers/</code>)</li>
        </ul>
        <hr>
        <p class="mb-0 text-muted">Silakan gunakan menu sidebar di sebelah kiri untuk mengakses fitur-fitur aplikasi.</p>
    </div>
</div>

