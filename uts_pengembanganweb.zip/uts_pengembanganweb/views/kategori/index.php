<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-tags"></i> Data Kategori</h2>
    <a href="index.php?page=kategori&action=create" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Tambah Kategori
    </a>
</div>

<div class="table-container">
    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th width="5%">No</th>
                <th width="25%">Nama Kategori</th>
                <th width="45%">Deskripsi</th>
                <th width="15%">Tanggal Dibuat</th>
                <th width="10%">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($kategori)): ?>
                <?php $no = 1; foreach ($kategori as $row): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['nama_kategori']); ?></td>
                    <td><?php echo htmlspecialchars($row['deskripsi'] ?? '-'); ?></td>
                    <td><?php echo date('d-m-Y', strtotime($row['created_at'])); ?></td>
                    <td>
                        <a href="index.php?page=kategori&action=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-action btn-sm">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="index.php?page=kategori&action=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-action btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus kategori ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data kategori</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

