            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-calculate subtotal in transaction form
        function calculateSubtotal(input) {
            const row = input.closest('.produk-row');
            const harga = parseFloat(row.querySelector('.harga-satuan').value) || 0;
            const jumlah = parseInt(row.querySelector('.jumlah').value) || 0;
            const subtotal = harga * jumlah;
            row.querySelector('.subtotal').textContent = 'Rp ' + subtotal.toLocaleString('id-ID');
        }
    </script>
</body>
</html>

