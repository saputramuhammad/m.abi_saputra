<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi E-Commerce MVC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar-brand {
            font-weight: bold;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .table-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        .sidebar {
            min-height: calc(100vh - 56px);
            background: #343a40;
        }
        .sidebar .nav-link {
            color: #fff;
            padding: 15px 20px;
            border-bottom: 1px solid #495057;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: #495057;
        }
        .sidebar .nav-link i {
            margin-right: 10px;
        }
        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-shop"></i> E-Commerce MVC
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 d-none d-md-block sidebar p-0">
                <nav class="nav flex-column">
                    <a class="nav-link <?php echo isset($_GET['page']) && $_GET['page'] == 'kategori' ? 'active' : ''; ?>" href="index.php?page=kategori">
                        <i class="bi bi-tags"></i> Kategori
                    </a>
                    <a class="nav-link <?php echo isset($_GET['page']) && $_GET['page'] == 'supplier' ? 'active' : ''; ?>" href="index.php?page=supplier">
                        <i class="bi bi-truck"></i> Supplier
                    </a>
                    <a class="nav-link <?php echo isset($_GET['page']) && $_GET['page'] == 'produk' ? 'active' : ''; ?>" href="index.php?page=produk">
                        <i class="bi bi-box-seam"></i> Produk
                    </a>
                    <a class="nav-link <?php echo isset($_GET['page']) && $_GET['page'] == 'transaksi' ? 'active' : ''; ?>" href="index.php?page=transaksi">
                        <i class="bi bi-cart-check"></i> Transaksi
                    </a>
                </nav>
            </div>
            <div class="col-md-10 main-content">

