<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-box-seam"></i> Edit Produk</h2>
    <a href="index.php?page=produk" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">
        <form action="index.php?page=produk&action=update&id=<?php echo $produk['id']; ?>" method="POST">
            <div class="mb-3">
                <label for="nama_produk" class="form-label">Nama Produk <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?php echo htmlspecialchars($produk['nama_produk']); ?>" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="id_kategori" class="form-label">Kategori <span class="text-danger">*</span></label>
                    <select class="form-select" id="id_kategori" name="id_kategori" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach ($kategori as $row): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo ($produk['id_kategori'] == $row['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['nama_kategori']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="id_supplier" class="form-label">Supplier <span class="text-danger">*</span></label>
                    <select class="form-select" id="id_supplier" name="id_supplier" required>
                        <option value="">-- Pilih Supplier --</option>
                        <?php foreach ($supplier as $row): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo ($produk['id_supplier'] == $row['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['nama_supplier']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="harga" class="form-label">Harga <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="harga" name="harga" min="0" step="0.01" value="<?php echo $produk['harga']; ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="stok" class="form-label">Stok <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="stok" name="stok" min="0" value="<?php echo $produk['stok']; ?>" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"><?php echo htmlspecialchars($produk['deskripsi'] ?? ''); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save"></i> Update
            </button>
        </form>
    </div>
</div>

