<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-box-seam"></i> Data Produk</h2>
    <a href="index.php?page=produk&action=create" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Tambah Produk
    </a>
</div>

<div class="table-container">
    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th width="5%">No</th>
                <th width="20%">Nama Produk</th>
                <th width="12%">Kategori</th>
                <th width="12%">Supplier</th>
                <th width="10%">Harga</th>
                <th width="8%">Stok</th>
                <th width="18%">Deskripsi</th>
                <th width="10%">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($produk)): ?>
                <?php $no = 1; foreach ($produk as $row): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['nama_produk']); ?></td>
                    <td><?php echo htmlspecialchars($row['nama_kategori'] ?? '-'); ?></td>
                    <td><?php echo htmlspecialchars($row['nama_supplier'] ?? '-'); ?></td>
                    <td>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                    <td><?php echo $row['stok']; ?></td>
                    <td><?php echo htmlspecialchars(substr($row['deskripsi'] ?? '-', 0, 50)) . (strlen($row['deskripsi'] ?? '') > 50 ? '...' : ''); ?></td>
                    <td>
                        <a href="index.php?page=produk&action=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-action btn-sm">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="index.php?page=produk&action=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-action btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada data produk</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

