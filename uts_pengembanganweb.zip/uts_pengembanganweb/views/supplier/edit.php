<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-truck"></i> Edit Supplier</h2>
    <a href="index.php?page=supplier" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">
        <form action="index.php?page=supplier&action=update&id=<?php echo $supplier['id']; ?>" method="POST">
            <div class="mb-3">
                <label for="nama_supplier" class="form-label">Nama Supplier <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="nama_supplier" name="nama_supplier" value="<?php echo htmlspecialchars($supplier['nama_supplier']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo htmlspecialchars($supplier['alamat'] ?? ''); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="telepon" class="form-label">Telepon</label>
                <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo htmlspecialchars($supplier['telepon'] ?? ''); ?>">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($supplier['email'] ?? ''); ?>">
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save"></i> Update
            </button>
        </form>
    </div>
</div>

