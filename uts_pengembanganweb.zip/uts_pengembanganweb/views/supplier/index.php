<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-truck"></i> Data Supplier</h2>
    <a href="index.php?page=supplier&action=create" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Tambah Supplier
    </a>
</div>

<div class="table-container">
    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th width="5%">No</th>
                <th width="20%">Nama Supplier</th>
                <th width="25%">Alamat</th>
                <th width="15%">Telepon</th>
                <th width="15%">Email</th>
                <th width="10%">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($supplier)): ?>
                <?php $no = 1; foreach ($supplier as $row): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['nama_supplier']); ?></td>
                    <td><?php echo htmlspecialchars($row['alamat'] ?? '-'); ?></td>
                    <td><?php echo htmlspecialchars($row['telepon'] ?? '-'); ?></td>
                    <td><?php echo htmlspecialchars($row['email'] ?? '-'); ?></td>
                    <td>
                        <a href="index.php?page=supplier&action=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-action btn-sm">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="index.php?page=supplier&action=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-action btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus supplier ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">Tidak ada data supplier</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

