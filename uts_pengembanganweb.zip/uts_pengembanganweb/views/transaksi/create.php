<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-cart-check"></i> Tambah Transaksi</h2>
    <a href="index.php?page=transaksi" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">
        <form action="index.php?page=transaksi&action=store" method="POST" id="form-transaksi">
            <div class="mb-3">
                <label for="nama_pembeli" class="form-label">Nama Pembeli <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="nama_pembeli" name="nama_pembeli" required>
            </div>

            <h5 class="mt-4 mb-3">Daftar Produk</h5>
            <div id="produk-container">
                <div class="row produk-row mb-3 border p-3 rounded">
                    <div class="col-md-4">
                        <label class="form-label">Produk</label>
                        <select class="form-select nama-produk" name="id_produk[]" required onchange="updateHarga(this)">
                            <option value="">-- Pilih Produk --</option>
                            <?php foreach ($produk as $row): ?>
                            <option value="<?php echo $row['id']; ?>" data-harga="<?php echo $row['harga']; ?>">
                                <?php echo htmlspecialchars($row['nama_produk']); ?> (Stok: <?php echo $row['stok']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Harga</label>
                        <input type="number" class="form-control harga-satuan" name="harga_satuan[]" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Jumlah</label>
                        <input type="number" class="form-control jumlah" name="jumlah[]" min="1" value="1" required oninput="calculateSubtotal(this)">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Subtotal</label>
                        <div class="form-control-plaintext subtotal">Rp 0</div>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="button" class="btn btn-danger btn-sm" onclick="removeProduk(this)">
                            <i class="bi bi-trash"></i> Hapus
                        </button>
                    </div>
                </div>
            </div>

            <button type="button" class="btn btn-success mb-4" onclick="addProduk()">
                <i class="bi bi-plus-lg"></i> Tambah Produk
            </button>

            <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> Simpan Transaksi
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function updateHarga(select) {
    const row = select.closest('.produk-row');
    const option = select.options[select.selectedIndex];
    const harga = option.getAttribute('data-harga') || 0;
    row.querySelector('.harga-satuan').value = harga;
    calculateSubtotal(row.querySelector('.jumlah'));
}

function calculateSubtotal(input) {
    const row = input.closest('.produk-row');
    const harga = parseFloat(row.querySelector('.harga-satuan').value) || 0;
    const jumlah = parseInt(row.querySelector('.jumlah').value) || 0;
    const subtotal = harga * jumlah;
    row.querySelector('.subtotal').textContent = 'Rp ' + subtotal.toLocaleString('id-ID');
}

function addProduk() {
    const container = document.getElementById('produk-container');
    const firstRow = container.querySelector('.produk-row');
    const newRow = firstRow.cloneNode(true);
    
    newRow.querySelector('.nama-produk').selectedIndex = 0;
    newRow.querySelector('.harga-satuan').value = '';
    newRow.querySelector('.jumlah').value = '1';
    newRow.querySelector('.subtotal').textContent = 'Rp 0';
    
    container.appendChild(newRow);
}

function removeProduk(button) {
    const container = document.getElementById('produk-container');
    const rows = container.querySelectorAll('.produk-row');
    if (rows.length > 1) {
        button.closest('.produk-row').remove();
    } else {
        alert('Minimal harus ada satu produk dalam transaksi!');
    }
}
</script>

