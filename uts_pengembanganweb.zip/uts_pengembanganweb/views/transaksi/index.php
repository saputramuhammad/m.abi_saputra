<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-cart-check"></i> Data Transaksi</h2>
    <a href="index.php?page=transaksi&action=create" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Tambah Transaksi
    </a>
</div>

<div class="table-container">
    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th width="5%">No</th>
                <th width="12%">Tanggal</th>
                <th width="18%">Nama Pembeli</th>
                <th width="25%">Produk</th>
                <th width="10%">Total Jumlah</th>
                <th width="12%">Total Harga</th>
                <th width="10%">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($transaksi)): ?>
                <?php $no = 1; foreach ($transaksi as $row): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo date('d-m-Y H:i', strtotime($row['tanggal'])); ?></td>
                    <td><?php echo htmlspecialchars($row['nama_pembeli']); ?></td>
                    <td><?php echo htmlspecialchars($row['produk_list'] ?? '-'); ?></td>
                    <td><?php echo $row['total_jumlah'] ?? 0; ?></td>
                    <td>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                    <td>
                        <a href="index.php?page=transaksi&action=show&id=<?php echo $row['id']; ?>" class="btn btn-info btn-action btn-sm">
                            <i class="bi bi-eye"></i>
                        </a>
                        <a href="index.php?page=transaksi&action=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-action btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus transaksi ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data transaksi</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

