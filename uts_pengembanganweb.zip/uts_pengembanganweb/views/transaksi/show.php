<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-cart-check"></i> Detail Transaksi</h2>
    <a href="index.php?page=transaksi" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Informasi Transaksi</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <td width="35%"><strong>ID Transaksi</strong></td>
                        <td>: #<?php echo $transaksi['id']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal</strong></td>
                        <td>: <?php echo date('d-m-Y H:i:s', strtotime($transaksi['tanggal'])); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Pembeli</strong></td>
                        <td>: <?php echo htmlspecialchars($transaksi['nama_pembeli']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Total Harga</strong></td>
                        <td>: <strong>Rp <?php echo number_format($transaksi['total_harga'], 0, ',', '.'); ?></strong></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0">Detail Produk</h5>
    </div>
    <div class="card-body p-0">
        <table class="table table-striped table-hover mb-0">
            <thead class="table-secondary">
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Harga Satuan</th>
                    <th>Jumlah</th>
                    <th class="text-end">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($transaksi['detail'])): ?>
                    <?php $no = 1; foreach ($transaksi['detail'] as $item): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($item['nama_produk']); ?></td>
                        <td>Rp <?php echo number_format($item['harga_satuan'], 0, ',', '.'); ?></td>
                        <td><?php echo $item['jumlah']; ?></td>
                        <td class="text-end">Rp <?php echo number_format($item['subtotal'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada detail produk</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot class="table-dark">
                <tr>
                    <td colspan="4" class="text-end"><strong>Total Harga:</strong></td>
                    <td class="text-end"><strong>Rp <?php echo number_format($transaksi['total_harga'], 0, ',', '.'); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

